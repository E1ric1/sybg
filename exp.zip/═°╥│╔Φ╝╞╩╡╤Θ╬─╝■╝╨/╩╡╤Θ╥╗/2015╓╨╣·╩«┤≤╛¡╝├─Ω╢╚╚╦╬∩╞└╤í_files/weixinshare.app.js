/**
 * @file Popup组件
 * @author Haonan Wang
 * @version 0.1.1
 * @copyright Haonan Wang
 */

/**
 * @namespace window
 */
;(function() {
	/**
	 * 语言增强支持
	 * @ignore
	 * @static
	 * @memberOf window
	 * @property {Function} isString 是否为字符串
	 * @property {Function} isArray 是否为数组
	 * @property {Function} isFunction 是否为方法
	 * @property {Function} isObject 是否为对象
	 */
	var UL = {
		isString: isType("String"),
		isArray: Array.isArray || isType("Array"),
		isFunction: isType("Function"),
		isObject: isType("Object")
	};
	/**
	 * DOM增强支持
	 * @ignore
	 * @static
	 * @memberOf window
	 * @property {Function} querySelector 查询节点
	 * @property {Function} hasClass 是否含有类名
	 * @property {Function} addClass 添加类
	 * @property {Function} removeClass 删除类
	 */
	var	UD = {
		querySelector: querySelector,
		byClass: byClass,
		hasClass: hasClass,
		addClass: addClass,
		removeClass: removeClass,
		addStyles: addStyles
	};
	/**
	 * 事件增强支持
	 * @ignore
	 * @static
	 * @memberOf window
	 * @property {Function} addEvent 添加事件
	 * @property {Function} removeEvent 删除事件
	 */
	var UE = {
		addEvent: addEvent,
		removeEvent: removeEvent
	};

	/**
	 * 接收一个选择器,生成基于该DOM节点的弹框对象,类似于jQuery的用法
	 * @class Popup
	 * @memberOf window
	 * @param {String} [selector=document.body] 选择器
	 * @example
	 * Popup('.test')
	 */
	var Popup = function(selector) {
		/**
		 * 节点列表
		 * @ignore
		 * @private
		 * @memberOf window.Popup
		 * @type {Object}
		 */
		this._nodes = {
			// 通过选择器获取目标节点
			targetEl: selector ? (UD.querySelector(selector) || document.body) : document.body,
			// 弹框节点
			popupEl: void 0,
			// 内容层节点
			containerEl: void 0,
			// 遮罩层节点
			maskEl: void 0
		};
		/**
		 * 弹窗开关状态
		 * @ignore
		 * @private
		 * @memberOf window.Popup
		 * @type {Boolean}
		 */
		this._isClosed = true;
		/**
		 * 是否为临时创建
		 * @ignore
		 * @private
		 * @memberOf window.Popup
		 * @type {Boolean}
		 */
		this._disposable = true;
		/**
		 * 是否允许背景层滚动
		 * @ignore
		 * @private
		 * @memberOf window.Popup
		 * @type {Boolean}
		 */
		this._backScroll = true;
		/**
		 * 是否有遮罩层,遮罩层上禁止页面滚动
		 * @ignore
		 * @private
		 * @memberOf window.Popup
		 * @type {Boolean}
		 */
		this._mask = true;
		/**
		 * 点击遮罩层时是否关闭弹框
		 * @ignore
		 * @private
		 * @memberOf window.Popup
		 * @type {Boolean}
		 */
		this._closeOnMask = false;
		/**
		 * 自定义事件列表
		 * @ignore
		 * @private
		 * @memberOf window.Popup
		 * @type {Object}
		 */
		this._eventsList = {};
		/**
		 * 存储目标节点滚动事件
		 * @ignore
		 * @private
		 * @memberOf window.Popup
		 * @type {Function}
		 */
		this._scrollEvent = void 0;
	};

	Popup.prototype = {
		/**
		 * 创建自定义弹框,使用该方式创建的弹框对象将会保存至手动销毁[.destroy()]
		 * @memberOf window.Popup#
		 * @param {Object} options 创建弹框所需参数
		 * @param {String|Element} options.content 弹框内容,若为节点,则节点需要放在body子一级
		 * @param {String} [options.prefixClass] 前缀class
		 * @param {Boolean} [options.backScroll=true] 是否允许背景层滚动
		 * @param {Boolean} [options.mask=true] 是否有遮罩层
		 * @param {Boolean} [options.closeOnMask=false] 点击遮罩层时是否关闭弹框
		 * @param {String|Number} [options.width] 弹框宽度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {String|Number} [options.height] 弹框高度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {Object} [options.offset] 弹框相对目标节点的偏移
		 * @param {String} [options.offset.top] 相对于目标节点顶部的偏移
		 * @param {String} [options.offset.right] 相对于目标节点右部的偏移
		 * @param {String} [options.offset.bottom] 相对于目标节点底部的偏移
		 * @param {String} [options.offset.left] 相对于目标节点左部的偏移
		 * @param {Function} [options.afterOpen] 打开前调用函数
		 * @param {Function} [options.afterClose] 关闭后调用函数
		 * @return {Object} 返回实例
		 * @example
		 * Popup('.test').create({
		 *     content: document.getElementById('showNode').innerHTML,
		 *     prefixClass: 'mypopup-',
		 *     mask: true,
		 *     closeOnMask: true,
		 *     backScroll: true,
		 *     width: 600,
		 *     height: 400,
		 *     offset: {
		 *        top: '10px',
		 *        left: '1em',
		 *        right: '0',
		 *        bottom: '1rem'
		 *     },
		 *     afterOpen: function(){console.log('我已经打开了')},
		 *     afterClose: function(){console.log('我已经关闭了')}
		 * })
		 */
		create: function(options) {
			var content = this.content = options.content;
			this.prefixClass = options.prefixClass || '';
			this._mask = options.mask === undefined ? true : options.mask;
			this._backScroll = options.backScroll === undefined ? true : options.backScroll;
			this._closeOnMask = options.closeOnMask || false;
			this.width = options.width;
			this.height = options.height;
			this.offset = options.offset;
			this._eventsList.afterOpen = options.afterOpen;
			this._eventsList.afterClose = options.afterClose;
			this._disposable = false;

			this._createDOM(content);
			this._bindEvents();

			return this;
		},

		/**
		 * 打开弹框
		 * @memberOf window.Popup#
		 * @param {String|Number} [width] 弹框宽度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {String|Number} [height] 弹框高度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {Object} [offset] 弹框相对目标节点的偏移
		 * @param {String} [offset.top] 相对于目标节点顶部的偏移
		 * @param {String} [offset.right] 相对于目标节点右部的偏移
		 * @param {String} [offset.bottom] 相对于目标节点底部的偏移
		 * @param {String} [offset.left] 相对于目标节点左部的偏移
		 * @return {Object} 返回实例
		 * @example
		 * //popup为实例
		 * popup.open()
		 */
		open: function(width, height, offset) {
			if (!this._isClosed) return this;

			var self = this,
				scrollEl = this._nodes.targetEl,
				top;

			// 标志弹窗已关闭
			this._isClosed = false;

			// 处理背景层不允许滚动的情况
			if (!this._backScroll) {
				if (scrollEl == document.body) {
					scrollEl =  document.documentElement.scrollTop == 0 ? scrollEl : document.documentElement;
					top = scrollEl.scrollTop;
				}

				if (typeof this._scrollEvent === 'undefined'){
					this._scrollEvent = scrollEl.onscroll;
				}

				scrollEl.onscroll = function() {
					scrollEl.scrollTop = top;
				}
			}

			this._nodes.popupEl.style.display = '';

			// 计算弹框大小和位置
			width = width || this.width;
			height = height || this.height;
			offset = offset || this.offset;
			this._calculateSize(width, height, offset);

			this._eventsList.afterOpen && this._eventsList.afterOpen();

			return this;
		},

		/**
		 * 关闭弹框,如果是非create方式创建的对象则关闭的同时销毁自身
		 * @memberOf window.Popup#
		 * @return {Object} 返回实例
		 * @example
		 * //popup为实例
		 * popup.close()
		 */
		close: function() {
			if (this._isClosed) return this;

			var scrollEl = this._nodes.targetEl;

			// 标志弹窗已打开
			this._isClosed = true;

			// 处理背景层不允许滚动的情况
			if (!this._backScroll) {
				if (scrollEl == document.body) {
					scrollEl =  document.documentElement.scrollTop == 0 ? scrollEl : document.documentElement;
				}
				scrollEl.onscroll = this._scrollEvent;
			}

			this._nodes.popupEl.style.display = 'none';

			this._eventsList.afterClose && this._eventsList.afterClose();

			// 如果是非create创建的对象,则关闭同时调用destroy
			if (this._disposable) {
				this.destroy();
				return true;
			} else {
				return this;
			}
		},

		/**
		 * 基于弹框内容,重新渲染
		 * @memberOf window.Popup#
		 * @return {Object} 返回实例
		 * @example
		 * //popup为实例
		 * popup.refresh()
		 */
		refresh: function() {
			this._calculateSize();
			return this;
		},

		/**
		 * 销毁实例
		 * @memberOf window.Popup#
		 * @return {Object} 返回实例
		 * @example
		 * //popup为实例
		 * popup.destroy()
		 */
		destroy: function() {
			var self = this;
			// 若弹窗未关闭，则先关闭
			if (!this._isClosed) {
				// 防止close中重复调用destroy
				this._disposable = false;
				this.close();
			}
			
			// 销毁事件
			UE.removeEvent(this._nodes.containerEl, 'click touchstart', function(e){
				self._onContainer.call(self, e);
			});
			if (this._mask) {
				UE.removeEvent(this._nodes.maskEl, 'click touchstart', function(e){
					self._onMask.call(self, e);
				});
			} 
			if (this._eventsList.promptEvent) {
				UE.removeEvent(this._nodes.okEl, 'click touchstart', this._eventsList.promptEvent);
			}

			// 还原销毁节点
			if (this.content && !UL.isString(this.content)) {
				document.body.appendChild(this.content);
			}
			this._nodes.targetEl.style.position = '';
			this._nodes.popupEl.parentNode.removeChild(this._nodes.popupEl);
		},

		/**
		 * 警告框 无需create,可直接调用
		 * @method alert
		 * @memberOf window.Popup#
		 * @param {String} txt 显示文本
		 * @param {Callback} [okCallback] 点击确定后回调
		 * @return {Object} 返回实例
		 * @example
		 * Popup('.test').alert('js是世界第二好的语言',function(){console.log('第一是谁')})
		 */
		/** 
		 * 警告框 无需create,可直接调用
		 * @method alert^2
		 * @memberOf window.Popup#
		 * @param {Object} params 可选参数
		 * @param {String} params.txt 显示文本
		 * @param {String} [params.okTxt=确定] 确定按钮文本
		 * @param {String} [params.prefixClass] 前缀class
		 * @param {Boolean} [params.backScroll=true] 是否允许背景层滚动
		 * @param {Boolean} [params.mask=true] 是否有遮罩层
		 * @param {Boolean} [params.closeOnMask=false] 点击遮罩层时是否关闭弹框
		 * @param {String|Number} [params.width] 弹框宽度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {String|Number} [params.height] 弹框高度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {Object} [params.offset] 弹框相对目标节点的偏移
		 * @param {String} [params.offset.top] 相对于目标节点顶部的偏移
		 * @param {String} [params.offset.right] 相对于目标节点右部的偏移
		 * @param {String} [params.offset.bottom] 相对于目标节点底部的偏移
		 * @param {String} [params.offset.left] 相对于目标节点左部的偏移
		 * @param {Callback} [params.okCallback] 点击确定后回调
		 * @return {Object} 返回实例
		 * @example
		 * Popup().alert({
		 * 	   txt: 'js是世界第二好的语言',
		 * 	   okTxt: 'ok',
		 * 	   prefixClass: 'myalert-',
		 * 	   mask: true,
		 * 	   closeOnMask: true,
		 * 	   backScroll: true,
		 * 	   width: 200,
		 * 	   height: 100,
		 * 	   offset: {
		 *        top: '10px',
		 *        left: '1em',
		 *        right: '0',
		 *        bottom: '1rem'
		 *     },
		 * 	   okCallback: function(){console.log('第一是谁')}
		 * })
		 */
		alert: function() {
			var txt, okTxt = '确定', content;

			if (UL.isObject(arguments[0])) {
				txt = arguments[0].txt;
				this.prefixClass = arguments[0].prefixClass ? arguments[0].prefixClass : '';
				okTxt = arguments[0].okTxt || okTxt;
				this._backScroll = arguments[0].backScroll === undefined ? true : arguments[0].backScroll;
				this._mask = arguments[0].mask === undefined ? true : arguments[0].mask;
				this._closeOnMask = arguments[0].closeOnMask || false;
				this.width = arguments[0].width;
				this.height = arguments[0].height;
				this.offset = arguments[0].offset;
				this._eventsList.okCallback = arguments[0].okCallback;
			} else if (UL.isFunction(arguments[1])) {
				txt = arguments[0];
				this._eventsList.okCallback = arguments[1];
			} else {
				txt = arguments[0];
			}

			this.prefixClass += ' alert-';

			content = '<p class="' + this._addPrefixClass(null, 'content', true) + '">' + txt + '</p><a class="' + this._addPrefixClass(null, 'ok', true) + ' popup-ok">' + okTxt + '</a>';

			this._createDOM(content);
			this._bindEvents();
			this.open();

			return this;
		},

		/**
		 * 确认框 无需create,可直接调用
		 * @method confirm
		 * @memberOf window.Popup#
		 * @param {String} txt 显示文本
		 * @param {Callback} [okCallback] 点击确定后回调
		 * @param {Callback} [cancelCallback] 点击取消后回调
		 * @return {Object} 返回实例
		 * @example
		 * Popup('.test').confirm('js是世界第二好的语言',function(){console.log('是的')},function(){console.log('我再想想')})
		 */
		/** 
		 * 确认框 无需create,可直接调用
		 * @method confirm^2
		 * @memberOf window.Popup#
		 * @param {Object} params 可选参数
		 * @param {String} params.txt 显示文本
		 * @param {String} [params.okTxt=确定] 确定按钮文本
		 * @param {String} [params.cancelTxt=取消] 取消按钮文本
		 * @param {String} [params.prefixClass] 前缀class
		 * @param {Boolean} [params.backScroll=true] 是否允许背景层滚动
		 * @param {Boolean} [params.mask=true] 是否有遮罩层
		 * @param {Boolean} [params.closeOnMask=false] 点击遮罩层时是否关闭弹框
		 * @param {String|Number} [params.width] 弹框宽度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {String|Number} [params.height] 弹框高度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {Object} [params.offset] 弹框相对目标节点的偏移
		 * @param {String} [params.offset.top] 相对于目标节点顶部的偏移
		 * @param {String} [params.offset.right] 相对于目标节点右部的偏移
		 * @param {String} [params.offset.bottom] 相对于目标节点底部的偏移
		 * @param {String} [params.offset.left] 相对于目标节点左部的偏移
		 * @param {Callback} [params.okCallback] 点击确定后回调
		 * @param {Callback} [params.cancelCallback] 点击取消后回调
		 * @return {Object} 返回实例
		 * @example
		 * Popup('#test').confirm({
		 *     txt: 'js是世界第二好的语言',
		 *     okTxt: 'ok',
		 *     cancelTxt: 'cancel',
		 *     prefixClass: 'myconfirm-',
		 *     mask: true,
		 *     closeOnMask: true,
		 *     backScroll: true,
		 *     width: 300,
		 *     height: 100,
		 *     offset: {
		 *        top: '10px',
		 *        left: '1em',
		 *        right: '0',
		 *        bottom: '1rem'
		 *     },
		 *     okCallback: function(){console.log('就是')},
		 *     cancelCallback: function(){console.log('我再想想')}
		 * })
		 */
		confirm: function() {
			var okTxt = '确定', cancelTxt = '取消', content;

			if (UL.isObject(arguments[0])) {
				txt = arguments[0].txt;
				okTxt = arguments[0].okTxt || okTxt;
				cancelTxt = arguments[0].cancelTxt || cancelTxt;
				this.prefixClass = arguments[0].prefixClass ? arguments[0].prefixClass : '';
				this._backScroll = arguments[0].backScroll === undefined ? true : arguments[0].backScroll;
				this._mask = arguments[0].mask === undefined ? true : arguments[0].mask;
				this._closeOnMask = arguments[0].closeOnMask || false;
				this.width = arguments[0].width;
				this.height = arguments[0].height;
				this.offset = arguments[0].offset;
				this._eventsList.okCallback = arguments[0].okCallback;
				this._eventsList.cancelCallback = arguments[0].cancelCallback;
			} else if (UL.isFunction(arguments[1])) {
				txt = arguments[0];
				this._eventsList.okCallback = arguments[1];
				this._eventsList.cancelCallback = arguments[2];
			} else {
				txt = arguments[0];
			}

			this.prefixClass += ' confirm-';

			content = '<p class="' + this._addPrefixClass(null, 'content', true) + '">' + txt + '</p><a class="' + this._addPrefixClass(null, 'ok', true) + ' popup-ok">' + okTxt + '</a><a class="' + this._addPrefixClass(null, 'cancel', true) + ' popup-cancel">' + cancelTxt + '</a>';

			this._createDOM(content);
			this._bindEvents();
			this.open();

			return this;
		},

		/**
		 * 提示框 无需create,可直接调用
		 * @method prompt
		 * @memberOf window.Popup#
		 * @param {String} txt 显示文本
		 * @param {Callback} [okCallback] 点击确定后回调
		 * @param {Callback} [cancelCallback] 点击取消后回调
		 * @return {Object} 返回实例
		 * @example
		 * Popup('.test').prompt('世界上最好的语言是什么',function(){console.log('就是这个')},function(){console.log('我再想想')})
		 */
		/** 
		 * 提示框 无需create,可直接调用
		 * @method prompt^2
		 * @memberOf window.Popup#
		 * @param {Object} params 可选参数
		 * @param {String} params.txt 显示文本
		 * @param {String} [params.okTxt=确定] 确定按钮文本
		 * @param {String} [params.cancelTxt=取消] 取消按钮文本
		 * @param {String} [params.placeholder=请输入] 输入框默认文本
		 * @param {String} [params.prefixClass] 前缀class
		 * @param {Boolean} [params.backScroll=true] 是否允许背景层滚动
		 * @param {Boolean} [params.mask=true] 是否有遮罩层
		 * @param {Boolean} [params.closeOnMask=false] 点击遮罩层时是否关闭弹框
		 * @param {String|Number} [params.width] 弹框宽度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {String|Number} [params.height] 弹框高度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {Object} [params.offset] 弹框相对目标节点的偏移
		 * @param {String} [params.offset.top] 相对于目标节点顶部的偏移
		 * @param {String} [params.offset.right] 相对于目标节点右部的偏移
		 * @param {String} [params.offset.bottom] 相对于目标节点底部的偏移
		 * @param {String} [params.offset.left] 相对于目标节点左部的偏移
		 * @param {Callback} [params.okCallback] 点击确定后回调
		 * @param {Callback} [params.cancelCallback] 点击取消后回调
		 * @return {Object} 返回实例
		 * @example
		 * Popup('#test').prompt({
		 *     txt: '世界上最好的语言是什么',
		 *     okTxt: 'ok',
		 *     cancelTxt: 'cancel',
		 *     placeholder: 'js',
		 *     prefixClass: 'myprompt-',
		 *     mask: true,
		 *     closeOnMask: true,
		 *     backScroll: true,
		 *     width: 350,
		 *     height: 200,
		 *     offset: {
		 *        top: '10px',
		 *        left: '1em',
		 *        right: '0',
		 *        bottom: '1rem'
		 *     },
		 *     okCallback: function(msg){console.log('就是这个'+msg)},
		 *     cancelCallback: function(){console.log('我再想想')}
		 * })
		 */
		prompt: function() {
			var self = this, 
				okTxt = '确定', 
				cancelTxt = '取消', 
				placeholder = '请输入';

			if (UL.isObject(arguments[0])) {
				txt = arguments[0].txt;
				okTxt = arguments[0].okTxt || okTxt;
				cancelTxt = arguments[0].cancelTxt || cancelTxt;
				placeholder = arguments[0].placeholder || placeholder;
				this.prefixClass = arguments[0].prefixClass ? arguments[0].prefixClass : '';
				this._backScroll = arguments[0].backScroll === undefined ? true : arguments[0].backScroll;
				this._mask = arguments[0].mask === undefined ? true : arguments[0].mask;
				this._closeOnMask = arguments[0].closeOnMask || false;
				this.width = arguments[0].width;
				this.height = arguments[0].height;
				this.offset = arguments[0].offset;
				this._eventsList.okCallback = arguments[0].okCallback;
				this._eventsList.cancelCallback = arguments[0].cancelCallback;
			} else if (UL.isFunction(arguments[1])) {
				txt = arguments[0];
				this._eventsList.okCallback = arguments[1];
				this._eventsList.cancelCallback = arguments[2];
			} else {
				txt = arguments[0];
			}

			this.prefixClass += ' prompot-';

			var content = '<p class="' + this._addPrefixClass(null, 'content', true) + '">' + txt + '</p><input class="' + this._addPrefixClass(null, 'input', true) + '" type="text" placeholder=' + placeholder + '><a class="' + this._addPrefixClass(null, 'ok', true) + ' popup-ok">' + okTxt + '</a><a class="' + this._addPrefixClass(null, 'cancel', true) + ' popup-cancel">' + cancelTxt + '</a>';

			this._createDOM(content);
			this._bindEvents();

			// 自定义事件
			var okEl = this._nodes.okEl = UD.querySelector(this._nodes.containerEl, '.prompot-ok'),
				inputEl = UD.querySelector(this._nodes.containerEl, '.prompot-input');

			this._eventsList.promptEvent = function(e) {
				var val = inputEl.value;

				self._eventsList.okCallback && self._eventsList.okCallback(val);
				self.close();

				if (typeof e.stopPropagation === 'function') {
    				e.stopPropagation();
				} else {
					e.cancelBubble = true;
				}
			}

			UE.addEvent(okEl, 'click touchstart', this._eventsList.promptEvent);

			this.open();

			inputEl.focus();

			return this;
		},

		/**
		 * 计算弹框尺寸
		 * @ignore
		 * @private
		 * @memberOf window.Popup#
		 * @param {String|Number} [width] 弹框宽度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {String|Number} [height] 弹框高度(不加单位或为数字则默认单位是px),若不设置(null或undefined)则自适应
		 * @param {Object} [offset] 弹框相对目标节点的偏移
		 * @param {String} [offset.top] 相对于目标节点顶部的偏移
		 * @param {String} [offset.right] 相对于目标节点右部的偏移
		 * @param {String} [offset.bottom] 相对于目标节点底部的偏移
		 * @param {String} [offset.left] 相对于目标节点左部的偏移
		 */
		_calculateSize: function(width, height, offset) {
			// 重置innerEl尺寸，以使其自适应所包含内容的大小
			this._nodes.innerEl.style.width = '';
			this._nodes.innerEl.style.height = '';

			var rootEl = (this._nodes.targetEl === document.body) ? document.documentElement : this._nodes.targetEl,
				maxHeight = rootEl.clientHeight,
				maxWidth = rootEl.clientWidth,
				reg = new RegExp('([\\d.]*)(\\w*)'),
				adjustWidth,
				adjustHeight,
				widthUnit,
				heightUnit,
				temp;

			if (width) {
				temp = reg.exec(width);
				adjustWidth = temp[1];
				widthUnit = temp[2] || 'px';
			} else {
				adjustWidth = this._nodes.innerEl.offsetWidth;
				widthUnit = 'px';
				if (adjustWidth > maxWidth - 100) {
					adjustWidth = maxWidth - 100;
				}
			}
			if (height) {
				temp = reg.exec(height);
				adjustHeight = temp[1];
				heightUnit = temp[2] || 'px';
			} else {
				adjustHeight = this._nodes.innerEl.offsetHeight;
				heightUnit = 'px';
				if (adjustHeight > maxHeight - 80) {
					adjustHeight = maxHeight - 80;
				}
			}

			UD.addStyles(this._nodes.innerEl, {
				width: adjustWidth + widthUnit,
				height: adjustHeight + heightUnit
			});
			UD.addStyles(this._nodes.containerEl, {
				width: adjustWidth + widthUnit,
				height: adjustHeight + heightUnit
			});

			if (this._mask) {
				UD.addStyles(this._nodes.containerEl, {
					top: offset && offset.top != undefined ? offset.top : '50%',
					right: offset && offset.right != undefined ? offset.right : null,
					bottom: offset && offset.bottom != undefined ? offset.bottom : null,
					left: offset && offset.left != undefined ? offset.left : '50%',
					marginTop: offset && (offset.top != undefined || offset.bottom != undefined) ? null : (-adjustHeight/2 + heightUnit),
					marginLeft: offset && (offset.left != undefined || offset.right != undefined) ? null : (-adjustWidth/2 + widthUnit)
				});
			} else {
				UD.addStyles(this._nodes.containerEl, {
					position: 'relative',
					top: 0,
					left: 0,
					marginTop: 0,
					marginLeft: 0
				});

				UD.addStyles(this._nodes.popupEl, {
					width: adjustWidth + widthUnit,
					height: adjustHeight + heightUnit,
					top: offset && offset.top != undefined ? offset.top : '50%',
					right: offset && offset.right != undefined ? offset.right : null,
					bottom: offset && offset.bottom != undefined ? offset.bottom : null,
					left: offset && offset.left != undefined ? offset.left : '50%',
					marginTop: offset && (offset.top != undefined || offset.bottom != undefined) ? null : (-adjustHeight/2 + heightUnit),
					marginLeft: offset && (offset.left != undefined || offset.right != undefined) ? null : (-adjustWidth/2 + widthUnit)
				});
			}
		},
		/**
		 * 创建弹框DOM
		 * @ignore
		 * @private
		 * @memberOf window.Popup#
		 * @param {String|Element} content 弹框内容HTML字符串或节点
		 */
		_createDOM: function(content) {
			var popupEl = this._nodes.popupEl = document.createElement('div'),
				containerEl = this._nodes.containerEl = document.createElement('div'),
				innerEl = this._nodes.innerEl = document.createElement('div'),
				maskEl = this._nodes.maskEl = document.createElement('div'),
				closeEl = this._nodes.closeEl = document.createElement('div');

			this._nodes.targetEl.style.position = 'relative';

			// 如果目标元素是body，则对弹框进行fixed定位
			this._addPrefixClass(popupEl, 'popup-wrapper');
			if (this._nodes.targetEl === document.body) {
				UD.addClass(popupEl, 'popup-inwindow');
			}

			// 若有遮罩层则创建之
			if (this._mask) {
				this._addPrefixClass(maskEl, 'popup-mask');
				popupEl.appendChild(maskEl);
			}

			// 创建关闭按钮
			closeEl.innerHTML = '×';
			this._addPrefixClass(closeEl, 'popup-close');
			containerEl.appendChild(closeEl);

			// 创建内容包裹节点
			this._addPrefixClass(containerEl, 'popup-container');
			this._addPrefixClass(innerEl, 'popup-inner');
			containerEl.appendChild(innerEl);
			popupEl.appendChild(containerEl);

			// 将内容添加进弹框
			if (UL.isString(content)) {
				innerEl.innerHTML = content;
			} else {
				innerEl.appendChild(content);
			}

			popupEl.style.display = 'none';
			this._nodes.targetEl.appendChild(popupEl);
		},
		/**
		 * 添加前缀class
		 * @ignore
		 * @private
		 * @memberOf window.Popup#
		 * @param {Element} ele class添加节点
		 * @param {String} cls 未加前缀的原class
		 * @param {Boolean} [withoutOrigin] 不保留要处理的class
		 */
		_addPrefixClass: function(ele, cls, withoutOrigin) {
			var precls = this.prefixClass.replace(/^\s+|\s+$/g,''),
				preclsArr = precls ? precls.replace(/\s+/g,' ').split(' ') : [],
				newCls = withoutOrigin ? '' : cls;

			for (var i = preclsArr.length - 1; i >= 0; i--) {
				newCls += ' ' + preclsArr[i] + cls;
			}

			ele && UD.addClass(ele, newCls);

			return newCls.replace(/^\s+/g,'');
		},
		/**
		 * 绑定弹框事件
		 * @ignore
		 * @private
		 * @memberOf window.Popup#
		 */
		_bindEvents: function() {
			var self = this;

			UE.addEvent(this._nodes.containerEl, 'click touchstart', function(e){
				self._onContainer.call(self, e);
			});

			if (this._mask) {
				UE.addEvent(this._nodes.maskEl, 'click touchstart', function(e){
					self._onMask.call(self, e);
				});
			} 
		},
		/**
		 * 内容层事件
		 * @ignore
		 * @private
		 * @memberOf window.Popup#
		 * @param {Event} e 事件对象
		 */
		_onContainer: function(e) {
			var e = e || window.event,
				src = e.target || e.srcElement,
				eventsList = this._eventsList;

			switch (true){
				case UD.hasClass(src, 'popup-close'):
					this.close();
					break;
				case UD.hasClass(src, 'popup-ok'):
					this.close();
					eventsList.okCallback && eventsList.okCallback();
					break;
				case UD.hasClass(src, 'popup-cancel'):
					this.close();
					eventsList.cancelCallback && eventsList.cancelCallback();
			}
		},
		/**
		 * 遮罩层事件
		 * @ignore
		 * @private
		 * @memberOf window.Popup#
		 * @param {Event} e 事件对象
		 */
		_onMask: function(e) {
			var e = e || window.event,
				src = e.target || e.srcElement,
				eventsList = this._eventsList;

			if (this._closeOnMask) {
				this.close();
			}
		}
	}

	Popup.prototype.constructor = Popup;

	window.Popup = function(selector) {
		return new Popup(selector);
	}

	/* 依赖函数 */
	function eventHandler(els, types, callback, onCatch, handler) {
		onCatch = onCatch ? true : false;

		var fn = {
			add: ['addEventListener', 'attachEvent'],
			remove: ['removeEventListener', 'detachEvent']
		},
		fn1 = fn[handler][0],
		fn2 = fn[handler][1];

		var eventStream = document[fn1] ? true : false,
			typeArr = types.replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '').split(' '),
			elArr = [].concat(els);

		for (var i = 0, len1 = elArr.length; i < len1; i++) {
	        var o = elArr[i];
	        for (var j = 0, len2 = typeArr.length; j < len2; j++) {
	        	eventStream ? o[fn1](typeArr[j], callback, onCatch) : o[fn2]("on" + typeArr[j], callback);
	        }
	    }
	}
	function addEvent(els, types, callback, onCatch) {
		eventHandler(els, types, callback, onCatch, 'add');
	}

	function removeEvent(els, types, callback, onCatch) {
		eventHandler(els, types, callback, onCatch, 'remove');
	}
	function isType(type) {
		return function(obj) {
			return Object.prototype.toString.call(obj) === '[object ' + type + ']';
		}
	}
	function querySelector() {
		var root, selector;
		if (typeof arguments[1] === 'undefined') {
			root = document;
			selector = arguments[0];
		} else {
			root = arguments[0];
			selector = arguments[1];
		}
		if (document.querySelector) {
			return root.querySelector(selector);
		} else {
			switch (true) {
				case (selector.indexOf('#') >= 0):
					return document.getElementById(selector.slice(1));
				case (selector.indexOf('.') >= 0):
					return byClass(selector.slice(1), root)[0];
				default:
					return root.getElementsByTagName(selector)[0];
			}
		}
	}
	function byClass(cls, root, tag) {
		if (!cls) return [];

		root = root ? (Object.prototype.toString.call(root) === '[object String]') ? document.getElementById(root) : root : document.body;
		tag = tag || '*';

		var resArr = [],
			els = root.getElementsByTagName(tag);

		var o1, o2, ref;
		for (var i = 0, len1 = els.length; i < len1; i++) {
			o1 = els[i];
			ref = o1.className.split(' ');
			for (var j = 0, len2 = ref.length; j < len2; j++) {
				o2 = ref[j];
				if (o2 === cls) {
					resArr.push(o1);
					break;
				}
			}
		}

		return resArr;
	}
	function hasClass(el, cls) {
		var reg = new RegExp('(^|\\s)' + cls + '($|\\s)');

		return reg.test(el.className);
	}
	function addClass(el, cls) {
		var clsArr = cls.replace(/^\s+|\s+$/g,'').replace(/\s+/g,' ').split(' '),
			elCls = el.className.replace(/^\s+|\s+$/g,'').replace(/\s+/g,' ');

		for (var i = clsArr.length - 1; i >= 0; i--) {
			if (!hasClass(el, clsArr[i])) {
				elCls += ' ' + clsArr[i];
			}
		}

		return el.className = elCls.replace(/^\s+/,'');
	}
	function removeClass(el, cls) {
		var rmCls = cls.replace(/^\s+|\s+$/g,'').replace(/\s+/g,'|'),
			elCls = el.className.replace(/^\s+|\s+$/g,'').replace(/\s+/g,' '),
			reg = new RegExp('(^|\\s)(' + rmCls + ')($|\\s)', 'g');

		return el.className = elCls.replace(reg, '$1$3').replace(/^\s+|\s+$/g,'').replace(/\s+/g,' ');
	}
	function addStyles(el, styles) {
		var styleList = el.style;

		for (var k in styles) {
			(styles[k] != undefined) && (styleList[k] = styles[k]);
		}
	}
})();
;(function() {
	var WeixinShare = {},
		sharePopup,
		shareUrl,
		maskStatus,
		defaultUrl = getDefaultUrl();

	WeixinShare.share = function (url, mask) {
		var _url, _mask;

		if (typeof url === 'boolean') {
			_mask = url;
			_url = defaultUrl;
		} else {
			_mask = mask || false;
			_url = url || defaultUrl;
		}

		if (_url === shareUrl && _mask === maskStatus) {
			sharePopup.open();
		} else {
			shareUrl = _url;
			maskStatus = _mask;

			htmlTpl = addUrlToTpl(shareUrl);
			sharePopup && sharePopup.destroy();
			sharePopup = Popup().create({
				content: htmlTpl,
				prefixClass: 'mypopup-',
				mask: _mask,
				closeOnMask: false,
				width: 262,
				height: 322
			});
			sharePopup.open();
		}
	}

	function getDefaultUrl() {
		var head = document.getElementsByTagName('head')[0],
			els = byAtrName('http-equiv', 'mobile-agent', head, 'meta');

		while (els.length) {
			var el = els.shift(),
				cnt = el.getAttribute('content');

			if (cnt.indexOf('url=') >= 0) {
				return cnt.substring(cnt.indexOf('url=') + 4);
			}
		}

		els = byAtrName('name', 'mobile-agent', head, 'meta');

		while (els.length) {
			var el = els.shift(),
				cnt = el.getAttribute('content');

			if (cnt.indexOf('url=') >= 0) {
				return cnt.substring(cnt.indexOf('url=') + 4);
			}
		}

		return window.location.href;
	}

	function addUrlToTpl(url) {
		return '<div class="weixin_popup">\
			<div class="weixin_popup_head">\
				<span>分享到微信朋友圈</span>\
			</div>\
			<div class="weixin_popup_main">\
				<img class="weixin_popup_img" src="http://comet.blog.sina.com.cn/qr?' + decodeURIComponent(url)
				+'" alt="">\
			</div>\
			<div class="weixin_popup_foot">打开微信，点击底部的“发现”，<br>使用“扫一扫”即可将网页分享至朋友圈。</div>\
		</div>';
	}

	function byAtrName(atrN, atrV, root, tag) {
		if (!atrN) return [];

		root = root ? (Object.prototype.toString.call(root) === '[object String]') ? doc.getElementById(root) : root : doc.body;
		tag = tag || '*';

		var resArr = [],
			els = root.getElementsByTagName(tag);

		var o;
		for (var i = 0, len = els.length; i < len; i++) {
			o = els[i];
			if (o.getAttribute(atrN) === (atrV || undefined)) {
				resArr.push(o);
			}
		}

		return resArr;
	}

	window.WeixinShare = WeixinShare;
})()