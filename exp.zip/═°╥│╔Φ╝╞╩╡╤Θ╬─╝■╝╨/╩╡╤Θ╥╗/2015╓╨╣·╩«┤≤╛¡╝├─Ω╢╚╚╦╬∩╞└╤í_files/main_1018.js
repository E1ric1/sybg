$(function(){
	var hiddenIframe = appendIframe(),
		hiddenForm = appendForm();
	var structItems, pop, searchResult,
		node = $('.js-popnode'),
		close = node.find('.js-close'),
		anchorWb = node.find('.js-wbshare');

	structItems = initVoteItem();
	initVoteEvent();
	sortItems(structItems);
	listenSearch(structItems);
	pop = Popup();
	close.on('click', function(e) {
    	pop.close();
    	//$('.popup-popup-wrapper').remove();
    })
	hiddenForm.target = hiddenIframe.name;

	function initVoteItem() {
		var items = [], vals = [];
		$(".js-citem").each(function(_, ele){
			var $item = $(ele),
				idDom, id, numDom, voteNum,
				item, searchStr, name, title;
				
			// 为票数赋值
			idDom = $item.find('.js-upvote')
			id = parseInt(idDom.data('voteid'));
			numDom = $item.find('.num');
			voteNum = parseInt(vote_options[id].replace(/,/g, ''));
			numDom.text(voteNum);
			if (isVoted(idDom)) {
				$item.find('.icon-zan').addClass('zand')
			}

			// 构建排序及搜索用的结构
			item = $item.get(0);
			name = $item.find('.txt-name').text();
			title = $item.find('.txt-position').text();
			searchStr = name + title;
			items.push([voteNum, item, searchStr]);
		});
		return items; 
	}

	// msg: [vid, str]
	window.vote_callback = function(msg) {

	};

	function initVoteEvent() {
		// 事件委托
		var survey_id = 112091, qid = 16535;
		$('.js-list').on('click', '.js-upvote', handle);
		function handle(e) {
			var $this = $(this), itemDom = $this.parents('.js-citem'),
				numDom, voteNum, aid, data,
				condName, title, imgUrl;
			//console.log($this)
			if (isVoted($this)) {
				alert('您好，您已投过票');
				return;
			}

			numDom = itemDom.find('.num');
			voteNum = parseInt(numDom.text());
			vid = $this.data('voteid');
			data = {poll_id: survey_id, 'q_16535[]': vid};
			numDom.text(++voteNum);
			itemDom.find('.icon-zan').addClass('zand')
			localStorage.setItem('sysd_' + vid + '_voted', 'true');
			sendReq(data)
			/*$.ajax({
				url: 'http://survey.news.sina.com.cn/api/server.php',
	            data: data,
	            dataType: 'jsonp',
	            success: function(){
	            }
			})*/
			//console.log(itemDom)
			condName = itemDom.find('.txt-name').text();
			title = itemDom.find('.txt-position').text();
			imgUrl = itemDom.find('img').attr('src');
			
			popup(condName, title, imgUrl);
		}

	    function popup(name, title, imgUrl) {
			var txtShare = '#2015中国十大经济年度人物#我在2015十大经济年度人物评选中投了'+ title + name + '一票哦，你也来投票吧~',
			urlwbShare = "javascript:toT(screen,document,encodeURIComponent,'','', '" + imgUrl + "', '" + txtShare + "');";
			anchorWb.attr('href', urlwbShare);
			pop.create({
			content: node.get(0),
			prefixClass: 'popup-',
			closeOnMask: false,
			mask: false,
			backScroll: false,
			width: 394,
			height: 251
			}).open();  
	    }
	}

	function sendReq(sendData) {
		var node;
		$(hiddenForm).empty();
		for (var key in sendData) {
			node = document.createElement('input');
			node.name = key;
			node.value = sendData[key].toString();
			hiddenForm.appendChild(node);
		}
		hiddenForm.submit();
	}

	function appendIframe() {
	  var iframe = document.createElement('iframe');
	  iframe.name = 'hiddenReq';
	  iframe.style.display= "none";
	  document.body.appendChild(iframe);
	  return iframe;
	}

	function appendForm() {
	  var form = document.createElement('form');
	  form.method = 'post';
	  form.action = 'http://survey.finance.sina.com.cn/polling.php';
	  form.style.display = 'none';
	  document.body.appendChild(form);
	  return form;
	}

	function isVoted(item) {
      var vid = item.data('voteid'),
        voted = localStorage.getItem('sysd_' + vid + '_voted') || 'false',
        prevTime = localStorage.getItem('sysd_' + vid + '_time'),
        nowTime = Date.now(),
        dayMsecs = 24 * 3600 * 1000;
      if (!prevTime || nowTime - parseInt(prevTime) > dayMsecs) {
          voted = 'false';
          localStorage.setItem('sysd_' + vid + '_time', nowTime);
          localStorage.setItem('sysd_' + vid + '_voted', voted);
      }
      return voted == 'true' ?  true : false;
  	}

  	function sortItems(items) {
  		var domItems = [], len = items.length
  		sort(items, function(item){
  			return item[0];
  		})
  		for (var i = 0; i < len; i++) 
  			domItems.push(items[i][1]);
  		$('.js-list').append(domItems);
  	}

  	
  	function sort(items, func) {
  	  var len = items.length, j, curItem, curValue;
  	  for (var i=0; i < len-1; i++) {
  	    j = i;
  	    curItem = items[j+1];
  	    curValue = func(curItem);
  	    while(j > -1) {
  	      if (curValue > func(items[j]))
  	        items[j+1] = items[j]
  	      else
  	        break;
  	      j--;
  	    }
  	    items[j+1] = curItem;
  	  }
  	}

    function listenSearch(data) {
    	$('.js-search').on('submit', function(e){
    		var $this = $(this),
    			btnSearch = $this.find('.txt'),
    			content = btnSearch.val(),
    			sidx, len, curItem,
    			tidx, rnum, top;
    		var domItems = [], $items;
    		if (content == '') {
    			$('.txt-name').removeClass('highlight');
				$('.txt-position').removeClass('highlight');
				$('.txt-name').removeClass('cur');
				$('.txt-position').removeClass('cur');
    			e.preventDefault();
	    		e.stopPropagation();
	    		return false;
    		}
    		if (searchResult && searchResult.val == content) {
    			len = searchResult.data.length;
    			if (len == 0) {
    				// console.log(len)
    				e.preventDefault();
    				e.stopPropagation();
    				return false;
    			}
    			sidx = searchResult.index;
    			tidx = searchResult.data[sidx][0];
    			for (var i = 0; i < len; i++) 
    				domItems.push(searchResult.data[i][1]);
    			$items = $(domItems)
    		} else {
    			$('.txt-name').removeClass('highlight');
				$('.txt-position').removeClass('highlight');
				$('.txt-name').removeClass('cur');
				$('.txt-position').removeClass('cur');
    			searchResult = search(content, data);
    			// console.log(searchResult)
    			len = searchResult.data.length
    			sidx = searchResult.index;
    			if (len == 0) {
    				// console.log(len)
    				e.preventDefault();
    				e.stopPropagation();
    				return false;
    			}
    			tidx = searchResult.data[0][0];

    			for (var i = 0; i < len; i++) 
    				domItems.push(searchResult.data[i][1]);
    			$items = $(domItems)
    			$items.find('.txt-name').addClass('highlight');
    			$items.find('.txt-position').addClass('highlight');
    		}
    		$items.find('.txt-name').removeClass('cur');
    		$items.find('.txt-position').removeClass('cur');
    		curItem = $(searchResult.data[sidx][1]);
    		curItem.find('.txt-name').addClass('cur');
    		curItem.find('.txt-position').addClass('cur');
    		searchResult.index = (sidx + 1) % len;
			rnum = parseInt(tidx / 5);
			top = 1438 + 353 * rnum;
			window.scrollTo(0, top);
/*    		$(document.documentElement).animate({
    			scrollTop: top
    		}, 600);*/
    		e.preventDefault();
    		e.stopPropagation();
    		return false;
    	});

    }

    function search(content, data) {
    	var result = {}, len = data.length,
    		tarStr, tarItem;
    	result.val = content = content || 'null';
    	result.data = [];
    	result.index = 0
    	if (content == 'null')
    		return reuslt;
    	//console.log(content)
    	for (var i = 0; i < len; i++) {
    		tarItem = data[i];
    		tarStr = tarItem[2];
    		//console.log(tarStr)
    		if(tarStr.indexOf(content) > -1)
    			result.data.push([i, tarItem[1]]);
    	}
    	return result;
    }
  
})

$(function() {
    $(".back-list").jCarouselLite({
        btnNext: ".back-btns .next-btn",
        btnPrev: ".back-btns .pre-btn"
        // auto: true,
    });
	seajs.use(['$','ScrollPic'],function($,ScrollPic){
	var scrollPic = new ScrollPic('scrollTop');
	scrollPic.onpagechange = function(index){
	  $('.scrollTxt').stop(0).animate({'bottom' : -32,'opacity' : 0},100,function(){
	    var title = $('.scrollTop .box').eq(index).data('title');
	    var url = $('.scrollTop .box').eq(index).find('a').attr('href');
	    $('.scrollTxt .sc').html('<h2><a target="_blank" href="' + url + '">' + title + '</a>' + '</h2>');
	  });
	};
	scrollPic.onpageend = function() {
	  $('.scrollTxt').stop(0).animate({'bottom' : 0,'opacity' : 1})
	};
	scrollPic.init();
	window.nincync = scrollPic;
	//console.log(scrollPic.slideObj.conf)
	})
});

//推荐到微博
function toT(s,d,e,r,l,pic,t,z,c){
  var f='http://v.t.sina.com.cn/share/share.php?',u=z||location.href,p=['url=',e(u),'&title=',e(t),'&source=',e(r),'&sourceUrl=',e(l),'&content=',c||'gb2312','&pic=',e(pic)].join('');
 function a(){if(!window.open([f,p].join(''),'mb',['toolbar=0,status=0,resizable=1,width=440,height=430,left=',(s.width-440)/2,',top=',(s.height-430)/2].join('')))u.href=[f,p].join('');
 };
 if(/Firefox/.test(navigator.userAgent))setTimeout(a,0);else a();
}